from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from .certificate import generate_certificate
from .database import Base, engine, get_db, SessionLocal
from .models import Certificate, GenerationJob
from .schemas import GenerationRequest, JobStatus

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Bulk Certificate Generation API", version="1.0.0")
executor = ThreadPoolExecutor(max_workers=4)


def process_certificate(certificate_id: int):
    db = SessionLocal()
    try:
        cert = db.get(Certificate, certificate_id)
        if not cert:
            return
        try:
            cert.status = "processing"
            db.commit()
            path = generate_certificate(
                certificate_id=cert.id,
                name=cert.recipient_name,
                title=cert.certificate_title,
                event=cert.event_name,
                issue_date=cert.issue_date,
            )
            cert.file_path = path
            cert.status = "completed"
        except Exception as exc:
            cert.status = "failed"
            cert.error_message = str(exc)[:1000]
        db.commit()
        job = db.get(GenerationJob, cert.job_id)
        if job:
            job.completed += 1
            if cert.status == "completed":
                job.successful += 1
            else:
                job.failed += 1
            job.status = "completed" if job.completed == job.total else "processing"
            db.commit()
    finally:
        db.close()

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/jobs", status_code=202)
def create_job(payload: GenerationRequest, db: Session = Depends(get_db)):
    job = GenerationJob(total=len(payload.recipients), status="queued")
    db.add(job)
    db.flush()
    cert_ids = []
    for recipient in payload.recipients:
        cert = Certificate(
            job_id=job.id,
            recipient_name=recipient.name,
            recipient_email=str(recipient.email),
            certificate_title=payload.certificate_title,
            event_name=payload.event_name,
            issue_date=payload.issue_date.isoformat(),
        )
        db.add(cert)
        db.flush()
        cert_ids.append(cert.id)
    job.status = "processing"
    db.commit()
    for cert_id in cert_ids:
        executor.submit(process_certificate, cert_id)
    return {"job_id": job.id, "status": "processing", "total": job.total}

@app.get("/jobs/{job_id}", response_model=JobStatus)
def get_job(job_id: int, db: Session = Depends(get_db)):
    job = db.get(GenerationJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    results = []
    for cert in job.certificates:
        results.append({
            "id": cert.id,
            "name": cert.recipient_name,
            "email": cert.recipient_email,
            "status": cert.status,
            "download_url": f"/certificates/{cert.id}" if cert.status == "completed" else None,
            "error": cert.error_message,
        })
    progress = round((job.completed / job.total) * 100, 2) if job.total else 100.0
    return JobStatus(id=job.id, status=job.status, total=job.total, completed=job.completed,
                     successful=job.successful, failed=job.failed,
                     progress_percent=progress, certificates=results)

@app.get("/certificates/{certificate_id}")
def download_certificate(certificate_id: int, db: Session = Depends(get_db)):
    cert = db.get(Certificate, certificate_id)
    if not cert:
        raise HTTPException(status_code=404, detail="Certificate not found")
    if cert.status != "completed" or not cert.file_path:
        raise HTTPException(status_code=409, detail=f"Certificate is {cert.status}")
    path = Path(cert.file_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Generated file is missing")
    return FileResponse(path, media_type="application/pdf", filename=path.name)

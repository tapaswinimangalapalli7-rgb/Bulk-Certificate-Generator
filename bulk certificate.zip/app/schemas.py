from datetime import date
from pydantic import BaseModel, EmailStr, Field, field_validator

class Recipient(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        value = " ".join(value.split())
        if not any(ch.isalpha() for ch in value):
            raise ValueError("name must contain letters")
        return value

class GenerationRequest(BaseModel):
    certificate_title: str = Field(default="Certificate of Participation", min_length=3, max_length=200)
    event_name: str = Field(min_length=2, max_length=200)
    issue_date: date = Field(default_factory=date.today)
    recipients: list[Recipient] = Field(min_length=1, max_length=5000)

    @field_validator("event_name", "certificate_title")
    @classmethod
    def clean_text(cls, value: str) -> str:
        return " ".join(value.split())

class RecipientResult(BaseModel):
    id: int
    name: str
    email: str
    status: str
    download_url: str | None = None
    error: str | None = None

class JobStatus(BaseModel):
    id: int
    status: str
    total: int
    completed: int
    successful: int
    failed: int
    progress_percent: float
    certificates: list[RecipientResult]

# Bulk Certificate Generation API

A FastAPI backend that accepts one request containing many recipients, validates the input, creates a background generation job, generates one PDF certificate per valid recipient, tracks progress in SQLite, and exposes each generated certificate for download.

## Stack
- Python 3.11+
- FastAPI
- SQLAlchemy + SQLite (relational database)
- ReportLab for PDF generation
- pytest + FastAPI TestClient

## Project structure

```text
certificate_api/
├── app/
│   ├── certificate.py       # predefined PDF template + generation
│   ├── database.py          # SQLite/SQLAlchemy setup
│   ├── main.py              # API + background processing
│   ├── models.py            # database models
│   └── schemas.py           # request/response validation
├── tests/test_api.py
├── generated/               # generated PDFs
├── requirements.txt
└── README.md
```

## Setup

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

## Run

```bash
uvicorn app.main:app --reload
```

API docs are then available at `/docs`.

## Submit a bulk generation request

`POST /jobs`

Example:

```json
{
  "certificate_title": "Certificate of Participation",
  "event_name": "Python Workshop 2026",
  "issue_date": "2026-10-07",
  "recipients": [
    {"name": "Alice Johnson", "email": "alice@example.com"},
    {"name": "Bob Smith", "email": "bob@example.com"},
    {"name": "Carol Davis", "email": "carol@example.com"}
  ]
}
```

The endpoint returns HTTP `202 Accepted` and a `job_id` immediately:

```json
{"job_id": 1, "status": "processing", "total": 3}
```

## Track progress

`GET /jobs/{job_id}`

Example response:

```json
{
  "id": 1,
  "status": "completed",
  "total": 3,
  "completed": 3,
  "successful": 3,
  "failed": 0,
  "progress_percent": 100.0,
  "certificates": [
    {
      "id": 1,
      "name": "Alice Johnson",
      "email": "alice@example.com",
      "status": "completed",
      "download_url": "/certificates/1",
      "error": null
    }
  ]
}
```

## Retrieve a certificate

`GET /certificates/{certificate_id}`

The API returns the generated PDF as a downloadable file.

## Validation and failure handling

- Names must contain letters and be 2–120 characters after whitespace normalization.
- Emails are validated using Pydantic's email validation.
- A batch supports up to 5,000 recipients in this implementation.
- Invalid request data is rejected with HTTP 422 before a job is created.
- Each certificate is processed independently. If one generation fails, that certificate is marked `failed` with an error message and other recipients continue processing.

## Design decisions

### Why background processing?
Certificate PDF creation can be slow for large batches. Returning `202 Accepted` immediately means the API request does not remain open while hundreds or thousands of PDFs are generated. A small `ThreadPoolExecutor` is used here to keep the project simple and dependency-light. For production-scale workloads, the executor can be replaced with Celery/RQ/Dramatiq backed by Redis or another queue.

### Why SQLite?
SQLite is a relational database and keeps local setup very small. SQLAlchemy makes the persistence layer easy to move to PostgreSQL/MySQL later.

### Why store certificate records separately?
Each recipient gets a database row, so the API can report per-recipient status, failures, and download URLs while the parent job stores aggregate progress.

### Why ReportLab?
It generates PDFs directly in Python and does not require a browser or external rendering service. The single template is deliberately contained in `app/certificate.py`, so changing the design is straightforward.

### Concurrency and failure isolation
Each recipient is submitted as an independent background task. A failure is caught inside that task and recorded against that certificate, so it does not terminate the batch.

## Tests

Run:

```bash
pytest -q
```

The test suite covers:
1. Creating a generation job
2. Input validation
3. Certificate generation
4. Job status/progress
5. Individual certificate failure without stopping the batch
6. Retrieving a generated PDF

## Interview explanation

The core flow is:

`POST /jobs -> validate -> create Job + Certificate rows -> enqueue each certificate -> generate PDFs -> update per-certificate status -> update job counters -> GET /jobs/{id} -> GET /certificates/{id}`

The important trade-off is that this implementation uses an in-process executor rather than a distributed queue. It is intentionally easy to understand and run for an interview assignment. If the requirement changes to multiple API servers or guaranteed processing after a server restart, the next modification would be a durable queue such as Celery + Redis and an object store such as S3 for generated files.

import os
from pathlib import Path
os.environ["PYTHONPATH"] = str(Path(__file__).resolve().parents[1])
from fastapi.testclient import TestClient
from app.main import app, executor

client = TestClient(app)

def wait_for_job(job_id, timeout=5):
    import time
    end = time.time() + timeout
    while time.time() < end:
        response = client.get(f"/jobs/{job_id}")
        data = response.json()
        if data["status"] == "completed":
            return data
        time.sleep(0.05)
    raise AssertionError("job did not finish")

def test_create_generation_job():
    response = client.post("/jobs", json={"event_name": "Python Workshop", "recipients": [{"name": "Alice", "email": "alice@example.com"}]})
    assert response.status_code == 202
    assert response.json()["total"] == 1

def test_input_validation():
    response = client.post("/jobs", json={"event_name": "X", "recipients": [{"name": "", "email": "bad"}]})
    assert response.status_code == 422

def test_certificate_generation_and_status():
    response = client.post("/jobs", json={"event_name": "FastAPI Course", "recipients": [{"name": "Bob", "email": "bob@example.com"}]})
    data = wait_for_job(response.json()["job_id"])
    assert data["successful"] == 1
    assert data["progress_percent"] == 100
    assert data["certificates"][0]["status"] == "completed"

def test_individual_certificate_failure_does_not_stop_others(monkeypatch):
    import app.main as main
    original = main.generate_certificate
    def fake(**kwargs):
        if kwargs["name"] == "Bad User":
            raise RuntimeError("simulated generation error")
        return original(**kwargs)
    monkeypatch.setattr(main, "generate_certificate", fake)
    response = client.post("/jobs", json={"event_name": "Mixed Batch", "recipients": [
        {"name": "Bad User", "email": "bad@example.com"},
        {"name": "Good User", "email": "good@example.com"},
    ]})
    data = wait_for_job(response.json()["job_id"])
    assert data["successful"] == 1
    assert data["failed"] == 1
    assert {x["status"] for x in data["certificates"]} == {"completed", "failed"}

def test_retrieve_generated_certificate():
    response = client.post("/jobs", json={"event_name": "Retrieval Test", "recipients": [{"name": "Carol", "email": "carol@example.com"}]})
    data = wait_for_job(response.json()["job_id"])
    certificate_id = data["certificates"][0]["id"]
    download = client.get(f"/certificates/{certificate_id}")
    assert download.status_code == 200
    assert download.headers["content-type"] == "application/pdf"
    assert download.content.startswith(b"%PDF")
